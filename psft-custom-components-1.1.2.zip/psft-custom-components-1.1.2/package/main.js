const config = require("./psft-lib/config/config");
const Environments = config.lib.environments();

const Component = require('./psft-oda-lib/component');

/**
 * Generates an ODA Custom Components Synchronously to for a Peoplesoft service by using the published metadata json.
 */
var getComponentsSync = function() {
var components = require('./components/registry');

  environments = Environments.get();
  for(envName in environments) {
    var services = Environments.get(envName).static_describe().Services;
    for(var service of services)
      components[envName + "." + service.IDForServiceURL] = new Component(envName, service);
  }
  
  return components;
}


module.exports.components = getComponentsSync();
