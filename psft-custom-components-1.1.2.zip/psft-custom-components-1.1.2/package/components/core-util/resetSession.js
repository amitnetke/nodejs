'use strict';
 

module.exports = {
  metadata: () => ({
    name: 'core.util.ResetSession',
    properties: {
      message: { required: false, type: 'string' },
      channels: { required: true, type: 'array'}
    },
    supportedActions: ['success', 'failure']
  }),
  invoke: (conversation, done) => {
    
    var resetMessage = conversation?conversation.properties()["message"]:undefined;
    var channels=conversation.properties()["channels"];
    conversation.logger().info('channel length'+channels.length);
    
    channels.forEach(function(channel){
    conversation.logger().info("Iterating through channel"+ channel);
        if( channel.toLowerCase() === conversation.channelType()){
          conversation.logger("Resetting the token for channel"+conversation.channelType());
          conversation.variable("profile.token","");
        }
    });

    if(resetMessage)
      conversation.reply(resetMessage)
    
    conversation.transition('success');
    done();
  }
};
