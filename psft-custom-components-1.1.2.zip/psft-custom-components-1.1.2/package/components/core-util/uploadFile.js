'use strict';
 

module.exports = {
  metadata: () => ({
    name: 'core.util.UploadFile',
    properties: {
      FileNamePrefix: { required: true, type: 'string' },
      UrlId: { required: true, type: 'string' }
    },
    supportedActions: ['success', 'failure']
  }),
  invoke: (conversation, done) => {
    var guid= conversation.variable("profile.token_guid");
    var dateObj=new Date();
    var YYYY=dateObj.getFullYear();
    var MM=((dateObj.getMonth()+1) <10)?('0'+(dateObj.getMonth()+1)):(dateObj.getMonth()+1);
    var DD=(dateObj.getDate() <10)?('0'+dateObj.getDate()):dateObj.getDate();
    var HH=(dateObj.getHours() <10)?('0'+dateObj.getHours()):dateObj.getHours();
    var MIN=(dateObj.getMinutes() <10)?('0'+dateObj.getMinutes()):dateObj.getMinutes();
    var SS=(dateObj.getSeconds() <10)?('0'+dateObj.getSeconds()):dateObj.getSeconds();

    var FilePrefix=guid+'_'+YYYY+''+MM+''+DD+''+HH+''+MIN+''+SS;

    FilePrefix=YYYY+''+MM+''+DD+''+HH+''+MIN+''+SS;
    var FileURLID= conversation.properties()['UrlId'];
    conversation.variable(conversation.properties()['FileNamePrefix'],FilePrefix);
    conversation.reply('<div class="attachmentContainer spinner" ><div id="attachedFileName" class="eocb_hidden" ></div><iframe onload="attachmentFrameLoad();" style="border:none;" id="attachFrame" src="https://slc08ais.us.oracle.com:8001/psc/h92twillx/EMPLOYEE/HRMS/c/PTRTE.EOCBUPLOAD.GBL?FLPRE='+FilePrefix+'&URLID='+FileURLID+'&TYPE=record://PTRTDB&INFO="/></iframe></div><div><input id="AttachBtn" onclick="uploadAttachment()" type="button" value="Attach"></div>');
    conversation.transition('success');
    done();
  }
};
