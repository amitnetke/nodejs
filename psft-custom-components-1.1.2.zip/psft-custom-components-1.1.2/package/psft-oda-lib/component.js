"use strict";

const config = require("../psft-lib/config/config");

const Services = config.lib.services();
const Session = config.lib.session();
const Logger = config.lib.logger();
const Environments = config.lib.environments();

/**
 * Generates an IBCS Component to for a Peoplesoft service by using the published metadata.
 * @class
 * @param {string} envName Environment Name
 * @param {string} svcName Service Name
 */
 function Component(envName, serviceMD) {

    var that = this;
     
    var svcName = serviceMD.IDForServiceURL;
    var logger=new Logger();
    logger.log("creating a component for service " + envName + "." + svcName);

    var componentMD = {
        "name": envName + "." + serviceMD.IDForServiceURL,
        "properties": {},
        "supportedActions": []
    };

    var param, state;

    if (serviceMD.IsMultiRowInput) {
        /** When the Input property of the Service Metadata has multiple rows , then the Component will have a single input parameter for
         * which is named as InputArray*/
        componentMD.properties["InputArray"] = {
            "type": "array",
            "required": false
        };

    } else {
        for (param of serviceMD.InputParameters)
            componentMD.properties[param.ParameterName] = {
                "type": param.DataType,
                "required": false
            };
    }


    if (serviceMD.IsMultiRowOutput) {
        /** When the Output property of the Service Metadata has multiple rows , there the Component will have a single output parameter for
         * which is named as OutputArray*/
        componentMD.properties["OutputArray"] = {
            "type": "array",
            "required": false
        };

    } else {
        for (param of serviceMD.OutputParameters)
            componentMD.properties[param.ParameterName] = {
                "type": param.DataType,
                "required": false
            };
    }

    for (state of serviceMD.ResultStates) {
        componentMD.supportedActions.push(state.Name);
    }

    var coreStates = ["pserror"];
    var errorState = "pserror";
    var psErrorDetailVar="pserrordetail";
    var psErrorCodeVar = "pserrorcode";
    var errorStates = {
        "AuthError": "AuthError",
        "GUIDAuthError": "GUIDAuthError",
        "ServiceError": "ServiceError",
        "SystemError": "SystemError"
    };

    for (state of coreStates) {
        componentMD.supportedActions.push(state);
    }

    that.metadata = function () {
        return componentMD;
    };

    that.invoke = function (conversation, done) {
        
        var payload = {};
        var logger=new Logger(conversation);
        var securedService=serviceMD.IsTokenMandatory;
        var token;
        var authType=conversation.variable("profile.tokentype")?conversation.variable("profile.tokentype"):"PSTOKEN";   
        
        var userSession =  new Session(conversation,envName);
        logger.log("Created Session for enviornment:"+envName);
        if(userSession){
            logger.log("Invoking Security Handshake Service");
            userSession.invokeSecurityHandshake(securedService).then(function(response){
                logger.log("Invocation of Handshake Service completed");
                token=conversation.variable("profile.token");
                logger.log("Token Retrieved from the conversation object is "+token);
                /** Setting the Input payload for before the Invokcation of Service */
                if (serviceMD.IsMultiRowInput) {
                    payload["InputArray"] = conversation.properties()["InputArray"];
                } else {
                    for (var param of serviceMD.InputParameters) {
                        payload[param.ParameterName] = param.DataType == 'Number'?Number(conversation.properties()[param.ParameterName]):conversation.properties()[param.ParameterName];
                    }
                }
                
                /** Invocation of Service after Handshake  */
                logger.log("Invocation of Peoplesoft Service"+ svcName +" with token :"+token+" and Auth type "+authType+"after Handshake ");
                
                Services.execute(Environments.get(envName, conversation), svcName, payload, token, Services.resolve.EVERYTHING, conversation,logger).catch(function (err) {
                    /** Error Handling for Service Invocation */
                    if(err.res && err.res.statusCode==200){
                        conversation.variable(psErrorCodeVar, errorStates["GUIDAuthError"]);
                      }else{
                        conversation.variable(psErrorCodeVar, errorStates["SystemError"]);
                      }
                    logger.log("Service Invocation Rejected with error "+ JSON.stringify(err));  
                    logger.log("Resetting the token value");
                    conversation.variable("profile.token","");

                    conversation.variable(psErrorDetailVar, JSON.stringify(err));
                    conversation.transition(errorState);
                    return done();

                }).then(function (response) {
                    // Important todo: response not authorized is not handled correctly.
                    logger.log("Completed Invocation of Service"+ svcName +" of Auth type "+authType);
                    var returnVals = response.body.ServiceOutputParameters;
                    if (response.body.ServiceOutputParameters === undefined) {
                        logger.log("No Data returned on Invocation of Service"+ svcName +"  of Auth type "+authType);
                        if (response.body.ParseStatus && (!response.body.Authorized)) {
                            conversation.variable(psErrorCodeVar, errorStates["AuthError"]);
                            logger.log("Resetting the token value");
                            conversation.variable("profile.token","");
                        } else {
                            conversation.variable(psErrorCodeVar, errorStates["ServiceError"]);
                        }
                        conversation.transition(errorState);
                        return done();
                    }

                    /** Setting the Service Output params on the Conversation Variable  */
                    if (serviceMD.IsMultiRowOutput) {
                        var varName = conversation.properties()["OutputArray"];
                        if (varName != undefined) {
                            conversation.variable(varName, returnVals);
                        }
                    } else {
                        for (var outputParam of serviceMD.OutputParameters) {
                            var varName = conversation.properties()[outputParam.ParameterName];
                            if (varName !== undefined) {
                                conversation.variable(varName, returnVals[outputParam.ParameterName]);
                            }
                        }
                    }

                    /** Setting the Service Result State on the Conversation Result State  */
                    if (response.body.ResultState) {
                        logger.log("Transitioning to the Result State "+ response.body.ResultState); 
                        conversation.transition(response.body.ResultState);
                    } else {
                        conversation.transition();
                    }
                    return done();  
                });

                
            }).catch( function(){
                conversation.transition(errorState);
                return done();

            });
        }
    
        
    };
}

module.exports = Component;