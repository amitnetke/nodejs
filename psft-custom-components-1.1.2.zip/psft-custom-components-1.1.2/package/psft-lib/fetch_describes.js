
const http = require('http');       
const https = require('https')

const configpath = "./config/";
const config = require(configpath + 'config');

const environments = config.require("./environments.json");



Object.keys(environments).forEach( (envName) => {
    var env = environments[envName];

    var req = env.baseURL.startsWith("https")?https:http;
    var options = {
        json: true, 
        headers: {
            "Authorization": "Basic " + Buffer.from(env.user + ":" + env.password).toString("base64")
        }
    };
    

    req.get(env.baseURL + "/describe", options, (res) => {
        var body = "";
        res.on("data", (d) => {
            body += d;
        });

        res.on("end", () => {
            const fs = require('fs');
            console.log("writing... " + configpath + env.static_describe);
            fs.writeFile(configpath + env.static_describe, body, function(err) {
                if(err) {
                    return console.log(err);
                }

                console.log("The file was saved!");
            }); 
        });
    }).on('error', (e) => {
        console.error(e);
    });;
});
