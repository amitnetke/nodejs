

var out = {
    "environments": require("./environments.json"),
    "libpaths": {
        "session": "../lib/session",
        "environments": "../lib/environments",
        "services": "../lib/services",
        "utilities": "../lib/utilities",
        "logger": "../lib/logger"
    },
    "lib": {
        "session": () => require(out.libpaths.session),
        "environments": () => require(out.libpaths.environments),
        "services": () => require(out.libpaths.services),
        "utilities": () => require(out.libpaths.utilities),
        "logger": () => require(out.libpaths.logger),
    },
    "require": (libpath) => require(libpath),
    "ready": true
}

module.exports = out;
