"use strict";
var ps = require("../ps.js");
var hcm = undefined, service = undefined;

describe("PS Chatbot Services", function() {
    beforeAll(async function() {
        ps = new ps();
        await ps.ready;
    });

    it("calling ps.get('env') gets an environment.", function() {
        hcm = ps.get("HCM");

        expect(hcm).toBeDefined();
    });

    it("calling environment.get('service') gets a service.", function() {
        service = ps.get("HCM").get("test.core.serviceFramework");

        expect(service).toBeDefined();
    });

    it("calling service.execute(payload) executes the service", async function() {

        var response = await ps.get("HCM").get("test.core.serviceframework").execute({"inputparam": "Test String"});
        
        expect(response).toEqual({ "outputparam": "Test String" });
    });

    it("Shorthand of ps.HCM.servicename.execute() executes the service.", async function() {
        var response = await ps.HCM['test.core.serviceframework'].execute({"inputparam": "Test String"});

        expect(response).toEqual({ "outputparam": "Test String" });
    });
});