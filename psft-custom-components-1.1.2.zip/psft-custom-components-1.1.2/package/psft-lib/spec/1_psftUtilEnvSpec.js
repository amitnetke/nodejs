"use strict";


var test_config = require("./test_config.json");


var config = require(test_config.config_path);
var env = config.lib.environments();


describe("Environments", function() {

    it("count() returns at least one environment.", function () {
        expect(env.count()).toBeGreaterThanOrEqual(1);
    });

    it("get() returns all the enviornments", function () {
        expect(Object.keys(env.get()).length).toBeGreaterThanOrEqual(1);
    });

    it("get('HCM') returns a valid connector", function () {
        expect(env.get("HCM")).toBeDefined();
    });

    it("get('XYZ') returns undefined", function () {
        expect(env.get("XYZ")).toBeUndefined();
    });
});
